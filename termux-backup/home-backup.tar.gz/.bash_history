& & pkg upgrade
pkg upgrade
ls /sdcard/fonts/Lato-Regular.ttf
wget https://fonts.google.com/download?family=Lato -O /sdcard/fonts/Lato-Regular.ttf
import aspose.words as aw
doc = aw.Document("input.pdf")
doc.font_settings.set_fonts_folder("/sdcard/fonts/", True)
toc_field = doc.range.start.insert_field("TOC", "")
toc_field.font.name = "Times New Roman"
doc.save("output_with_toc.pdf")
fc-list | grep Lato
# Step 1: Discover devices on your network (run these in Command Prompt or Terminal)
# For Windows:
ipconfig  # Find your network's IP range (e.g., 192.168.1.x) under "IPv4 Address" and "Subnet Mask"
arp -a  # Lists all devices on your network with their IP and MAC addresses
# For macOS/Linux:
ifconfig | grep inet  # Find your network's IP range (e.g., 192.168.1.x)
arp -a  # Lists all devices on your network with their IP and MAC addresses
# Step 2: Scan for devices (optional, requires nmap installation)
# Install nmap: Windows (download from nmap.org), macOS (brew install nmap), Linux (sudo apt-get install nmap)
nmap -sn 192.168.1.0/24  # Replace 192.168.1.0/24 with your network's IP range
# Step 3: Ping a specific device to confirm it’s active
ping 192.168.1.100  # Replace with the IP address of the webcam or mobile device
echo "y" | pkg update -y && echo "y" | pkg install termux-api portaudio python -y && echo "y" | pip install pyaudio speechrecognition pocketsphinx --no-deps && echo "y" | termux-setup-storage && termux-microphone-record -f $HOME/test.wav -l 3 && touch /storage/emulated/0/Download/test.txt && termux-tts-speak "Setup complete" && killall python 2>/dev/null && echo 'take note
take notes
tape note
tape notes' > $HOME/takenote.gram && echo 'import speech_recognition as sr, subprocess, time, datetime
r = sr.Recognizer()
r.energy_threshold = 100
r.dynamic_energy_threshold = True
with sr.Microphone() as source:
    print("Calibrating microphone...")
    r.adjust_for_ambient_noise(source, duration=2)
    while True:
        try:
            print("Listening for Take Note...")
            audio = r.listen(source, timeout=5, phrase_time_limit=4)
            text = r.recognize_sphinx(audio, grammar="$HOME/takenote.gram")
            print(f"Recognized: {text}")
            if any(phrase in text.lower() for phrase in ["take note", "take notes", "tape note", "tape notes"]):
                print("Trigger detected, recording...")
                filename = "/storage/emulated/0/Download/note_" + time.strftime("%Y-%m-%d_%H%M%S") + ".wav"
                result = subprocess.run(["termux-microphone-record", "-f", filename, "-l", "5"], capture_output=True, text=True)
                print(f"Recording result: {result.stdout}, {result.stderr}")
                subprocess.run(["termux-toast", f"Note saved as {filename}"])
                subprocess.run(["termux-tts-speak", "Noteworthy transmission stored in the matrix"])
                print(f"Saved: {filename}")
            else:
                print("No trigger detected")
        except Exception as e:
            print(f"Error: {e}")
            pass' > $HOME/take_note.py && termux-wake-lock && python $HOME/take_note.py & disown
/python $HOME/take_note.py
